# Easy Programming Tools

This package provides simple functions to make programming tasks easier, including basic math functions and string manipulations.

## Installation

```bash
pip install easy_programming_tools
